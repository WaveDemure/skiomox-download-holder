window.onbeforeunload = function () 
{
    chrome.tabs.query({}, function(foundTabs) {
        var tabsCount = foundTabs.length;
        console.info("tabsCount = " + tabsCount);
        if (tabsCount < 2) {
            window.close()
            chrome.tabs.create({ url: "" })
        }
    });
}